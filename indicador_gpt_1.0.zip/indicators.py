def calcular_indicadores(ativo, tipo_ativo):
    return {
        "EMA": 1,
        "RSI": 1,
        "MACD": 1
    }
