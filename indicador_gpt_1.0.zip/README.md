# INDICADOR GPT 1.0

Sistema de geração de sinais para operações de 1 minuto com IA e dados em tempo real.

## Rodar o projeto

```bash
pip install -r requirements.txt
streamlit run app.py
```
